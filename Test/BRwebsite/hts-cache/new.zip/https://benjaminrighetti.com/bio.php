<!DOCTYPE html>
<html lang="en" class="normal">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Biography — Benjamin Righetti</title>
<link rel="stylesheet" href="style.css">
<link href="img/favicon.png" rel="icon" sizes="256x256" type="image/png">
</head>
<body class="normal pastEvents biography">
<header class="flex">
<a class="nom nomL" href="./">
Benjamin <br />Righetti
</a>
</header>
<div class="wrap">
<h2 class="grosTitre2">Bio<br />graphy</h2>
</div>
<section class="SNextPast">
<div class="period">

<div class="liste flex" id="en">
<div class="gauche">
<div class="year yearL">
<div>En</div>
</div>
</div>
<div class="dates">

<p class="indent">"An immensely talented performer" (Diapason), Benjamin Righetti is a Swiss musician, titular organist at Saint-François, artistic director of the <a target="_blank" href="https://organopole.com">Organopole Foundation</a> and professor at the the <a target="_blank" href="https://hemu.ch">University of Music, Lausanne (HEMU)</a>. Alternating between the roles of soloist renowned for his virtuosity (more than 700 concerts to date), recording enthusiast, researcher (articles available on <a target="_blank" href="https://orgue.art">orgue.art</a>), he plays the organ repertoire with a contemporary and historically informed eye, and works, as a transcriber and composer (catalog available on <a target="_blank" href="https://imslp.org/wiki/List_of_works_by_Benjamin_Righetti">imslp.com</a>), to renew it. Benjamin Righetti loves both the mountains and the lakes of his small country and tries to balance his varied activities with rigor and joy.</p>
<p class="indent"><a target="_blank" href="https://benjaminrighetti.com">benjaminrighetti.com</a><br /></p>
</div>
</div>

<div class="liste flex">
<div class="gauche">
<div class="year yearL">
<div>En<br />glish</div>
</div>
</div>
<div class="dates">

<p class="indent">"One of the most brilliant organists of his generation" (Revue musicale de Suisse romande), "an immensely talented performer" (Diapason), Benjamin Righetti is a Swiss musician, titular organist at St-François and professor at the University of Music, Lausanne (HEMU).</p>
<p class="indent">Born in Switzerland in 1982, Benjamin Righetti discovered and became passionate about keyboard instruments at a very young age. He studied the piano in the class of Jean-François Antonioli and organ with Yves Rechsteiner, François Delor, Jean Boyer, Jan Willem Jansen, Michel Bouvard and Philippe Lefebvre. He also regularly practices clavichord and fortepiano. An unclassifiable instrumentalist, or perhaps just an authentic organist, it is in any case at the keyboards of the King of Instruments that he was the laureate of the most prestigious international competitions, from 2002 to 2007: Swiss Organ Competition, Musica Antiqua of Bruges, Tokyo-Musashino Organ Competition, 1st prize at the Silbermann Competition of Freiberg, public prize at Chartres, and Grand Prix d'orgue of the City of Paris. During his studies, he was supported by the Migros Cultural Percentage, the Irene Dénéréaz Foundation and Pro Helvetia.</p>
<p class="indent">Since then, he has divided his time between concert activities, church music and teaching. Among the more than 700 concerts he has already given to date, some memorable memories: in Notre-Dame de Paris on her 25th birthday, at the Toulouse les Orgues Festival in many editions, for the millennial celebrations of the Cathedral of Chartres, as soloist with OSR at the Concertgebouw in Amsterdam and at the Victoria Hall in Geneva, during the Bachfest closing concert at the Dom of Freiberg, at St Jakobi in Lübeck, at the Essen Philharmonic, at St Michael in München, at the Hospital of the Venerable in Seville and Barcelona Cathedral, for the 800th concert of the Martinikerk in Groningen, in Italy in the Cathedrals of Parma or Messina, in the concert hall of the Moscow Conservatory, at the Mariinsky Theatre in St Petersburg... As a duo, he regularly performs with Antoine Auberson (saxophone) and is a privileged partner of choir conductors Renaud Bouvier and Dominique Tille.</p>
<p class="indent">On the recording side, he has released five albums, all of which are currently available from Claves Records: Johann Sebastian Bach's Trio Sonatas in 2010, his transcription of Franz Liszt's Sonata in B minor and Missa choralis in 2011, César Franck's and Johannes Brahms's Chorales in 2013, Felix Mendelssohn's Sonatas in 2016 and "Flowers of degrowth" in 2020. His publications have been acknowledged by international critics (5 of Diapason, the essentials of Diapason d'or, Orphée d'or, Key of the month of Resmusica, 5 stars of Musica...), both for their originality and for the mastery of their production. He also produces music videos for its YouTube channel.</p>
<p class="indent">Finally, Benjamin Righetti pursues a research activity, regularly writing articles for the website orgue.art and the magazine La Tribune de l'Orgue. He also produces organ transcriptions and occasionally composes original works (available on imslp.org), often for educational purposes, for his students or for himself.</p>
<p class="indent"><a target="_blank" href="https://benjaminrighetti.com">benjaminrighetti.com</a><br /></p>
</div>
</div>

<div class="liste flex" id="fr">
<div class="gauche">
<div class="year yearL">
<div>Fr</div>
</div>
</div>
<div class="dates">

<p class="indent">«Un interprète immensément talentueux» (Diapason), Benjamin Righetti est un musicien suisse, organiste titulaire de Saint-François, directeur artistique de la <a target="_blank" href="https://organopole.com">Fondation Organopole</a> et professeur à la <a target="_blank" href="https://hemu.ch">Haute École de Musique de Lausanne</a>. Soliste réputé pour sa virtuosité (plus de 700 concerts à ce jour), chercheur (articles disponibles sur <a target="_blank" href="https://orgue.art">orgue.art</a>), passionné d'enregistrement, il joue le répertoire de l'orgue avec un regard aussi historiquement informé qu'actuel, et oeuvre, comme transcripteur et compositeur (catalogue disponible sur <a target="_blank" href="https://imslp.org/wiki/List_of_works_by_Benjamin_Righetti">imslp.com</a>), à son renouvellement. Amoureux tant des montagnes que des lacs de son petit pays, il tente de concilier ses nombreuses activités avec rigueur et joie.</p>
<p class="indent"><a target="_blank" href="https://benjaminrighetti.com">benjaminrighetti.com</a><br /></p>
</div>
</div>

<div class="liste flex">
<div class="gauche">
<div class="year yearL">
<div>Fran<br />çais</div>
</div>
</div>
<div class="dates">

<p class="indent">"l’un des organistes les plus brillants de sa génération" (Revue musicale de Suisse romande), «Un interprète immensément talentueux» (Diapason), Benjamin Righetti est un musicien suisse, organiste titulaire de Saint-François, directeur artistique de la Fondation Organopole et professeur à la Haute École de Musique de Lausanne.</p>
<p class="indent">Né en Suisse en 1982, Benjamin Righetti découvre et se passionne très jeune pour les instruments à clavier. Il étudie le piano dans la classe de Jean-François Antonioli et l'orgue avec Yves Rechsteiner, François Delor, Jean Boyer, Jan Willem Jansen, Michel Bouvard et Philippe Lefebvre. Il pratique aussi régulièrement le clavicorde et le pianoforte. Instrumentiste inclassable, ou peut-être justement authentique organiste, c'est en tout cas aux claviers du roi des instruments qu'il a été lauréat des plus prestigieux concours internationaux, de 2002 à 2007 : Concours Suisse de l'orgue, Musica Antiqua de Bruges, Concours d'orgue de Tokyo-Musashino, 1er prix du Concours Silbermann de Freiberg, prix du public à Chartres, et Grand Prix d'orgue de la Ville de Paris. Il a été soutenu durant ses études par le Pourcent Culturel Migros, la Fondation Irène Dénéréaz et Pro Helvetia.</p>
<p class="indent">Depuis lors, il partage son temps entre des activités de concertiste, de musicien d'Église et d'enseignant. Parmi les plus de 700 concerts qu'il a déjà donnés à ce jour, quelques souvenirs marquants : à Notre-Dame de Paris le jour de ses 25 ans, au Festival Toulouse les Orgues lors de nombreuses éditions, pour les festivités du millénaire de la Cathédrale de Chartres, en soliste avec l'OSR au Concertgebouw d'Amsterdam et au Victoria Hall de Genève, lors du concert de clôture de la Bachfest au Dom de Freiberg, à St Jakobi de Lübeck, à la Philharmonie de Essen, à St Michael de München, à l'Hôpital des Vénérables à Sevilla et à la Cathédrale de Barcelona, pour le 800e concert de la Martinikerk à Groningen, en Italie dans les Cathédrales de Parma ou de Messina, dans la salle de concert du Conservatoire de Moscou, au Théâtre Mariinsky de St-Petersbourg... En duo, il se produit régulièrement avec Antoine Auberson (saxophone) et est un complice privilégié des chefs de choeurs Renaud Bouvier et Dominique Tille.</p>
<p class="indent">Du côté des enregistrements, il a publié cinq albums, actuellement tous disponibles chez Claves records : les Sonates en trio de Johann Sebastian Bach en 2010, sa transcription de la Sonate en si mineur et la Missa choralis de Franz Liszt en 2011, les Chorals de César Franck et Johannes Brahms en 2013, les Sonates de Felix Mendelssohn en 2016 et "Flowers of degrowth" en 2020. Ses publications ont été saluées par la critique internationale (5 de Diapason, les indispensables de Diapason d'or, Orphée d'or, Clé du mois de Resmusica, 5 étoiles de Musica...) tant pour leur originalité que pour la maîtrise de leur réalisation. Il produit également des vidéos musicales pour sa chaîne YouTube.</p>
<p class="indent">Enfin, Benjamin Righetti poursuit une activité de recherche, rédigeant régulièrement des articles pour le site orgue.art et la revue La Tribune de l'Orgue. Il réalise aussi des transcriptions pour orgue et compose des oeuvres originales (catalogue et paritions disponibles sur imslp.org), souvent à but pédagogique, pour ses élèves ou pour lui-même.</p>
<p class="indent"><a target="_blank" href="https://benjaminrighetti.com">benjaminrighetti.com</a><br /></p>
</div>
</div>

<div class="liste flex" id="de">
<div class="gauche">
<div class="year yearL">
<div>De</div>
</div>
</div>
<div class="dates">

<p class="indent">"Ein ungeheurer begabter Interpret" (Diapason), Benjamin Righetti ist Titularorganist der Kirche Saint-François und Dozent am Konservatorium und an der Musikhochschule Lausanne. Daneben pflegt er eine regelmäßige Konzerttätigkeit auf der ganzen Welt, mit bis heute über 700 Konzerten und mit Aufnahmen für CD Radio, Fernsehen und Internet. Er liebt die Berge und die Seen seines kleinen Landes und ist dazu Redaktor der Website orgue.art. All diese zahlreichen Aktivitäten versucht er mit Gewissenhaftigkeit und Freude miteinander zu vereinbaren.</p>
<p class="indent"><a target="_blank" href="https://benjaminrighetti.com">benjaminrighetti.com</a><br /></p>
</div>
</div>

<div class="liste flex">
<div class="gauche">
<div class="year yearL">
<div>Deu<br />tsch</div>
</div>
</div>
<div class="dates">

<p class="indent">"Einer der brillantesten Organisten seiner Generation" (Revue musicale de Suisse romande), "ein ungeheurer begabter Interpret" (Diapason), Benjamin Righetti ist Titularorganist der Kirche Saint-François in Lausanne und Dozent am Konservatorium und an der Musikhochschule Lausanne (HEMU).</p>
<p class="indent">Benjamin Righetti, 1982 in der Schweiz geboren, entdeckte und begeisterte sich schon in jungen Jahren für Tasteninstrumente. Er studierte Klavier in der Klasse von Jean-François Antonioli und Orgel bei Yves Rechsteiner, François Delor, Jean Boyer, Jan Willem Jansen, Michel Bouvard und Philippe Lefebvre. Außerdem übt er regelmäßig Clavichord und Fortepiano. Nicht klassifizierbarer Instrumentalist oder vielleicht nur ein authentischer Organist, jedenfalls war er von 2002 bis 2007 Preisträger der renommiertesten internationalen Wettbewerbe: Schweizer Orgelwettbewerb, Musica Antiqua von Brügge, Tokyo-Musashino Orgelwettbewerb, 1. Preis am Silbermann-Wettbewerb von Freiberg, Publikumspreis von Chartres und Grand Prix d'orgue der Stadt Paris. Während des Studiums wurde er vom Migros-Kulturprozent, der Irene Dénéréaz Stiftung und Pro Helvetia unterstützt.</p>
<p class="indent">Seitdem teilt er seine Zeit auf Konzerttätigkeit, Kirchenmusik und Unterricht auf. Unter den mehr als 700 Konzerten, die er bisher gegeben hat, sind einige unvergessliche Erinnerungen: in Notre-Dame de Paris an ihrem 25. Geburtstag, beim Toulouse les Orgues Festival in vielen Auflagen, bei den tausendjährigen Feiern des Doms von Chartres, als Solistin mit OSR im Concertgebouw in Amsterdam und in der Victoria Hall in Genf, während des Bachfest-Abschlusskonzertes im Dom de Freiberg, im St. Jakobi in Lübeck, in der Essener Philharmonie, in St. Michael in München, im Krankenhaus des Ehrwürdigen in Sevilla und im Dom von Barcelona, für das 800. Konzert der Martinikerk in Groningen, in Italien in den Kathedralen von Parma oder Messina, im Konzertsaal des Moskauer Konservatoriums, im Mariinsky-Theater in St. Petersburg... Als Duo tritt er regelmäßig mit Antoine Auberson (Saxophon) auf und ist ein privilegierter Partner der Chorleiter Renaud Bouvier und Dominique Tille.</p>
<p class="indent">Auf der Aufnahmeseite hat er vier CDs veröffentlicht, die derzeit alle bei Claves Records erhältlich sind: Johann Sebastian Bachs Triosonaten 2010, seine Transkription von Franz Liszts Sonate h-Moll und Missa choralis 2011, César Franck und Johannes Brahms' Choräle 2013 und Felix Mendelssohns Sonaten 2016. Seine Veröffentlichungen wurden alle von internationalen Kritikern gelobt (5 von Diapason, das Wesentliche von Diapason d'or, Orphée d'or, Schlüssel des Monats Resmusica, 5 Sterne von Musica....), sowohl für ihre Originalität als auch für die Beherrschung ihrer Produktion. Außerdem produziert er Musikvideos für seinen YouTube-Kanal.</p>
<p class="indent">Schließlich betreibt Benjamin Righetti auch eine Forschungstätigkeit und schreibt regelmäßig Artikel für die Website orgue.art und die Zeitschrift La Tribune de l'Orgue. Er produziert auch Organtranskriptionen und komponiert gelegentlich Originalwerke (verfügbar unter imslp.org), oft zu Bildungszwecken, für seine Schüler oder für sich selbst.</p>
<p class="indent"><a target="_blank" href="https://benjaminrighetti.com">benjaminrighetti.com</a><br /></p>
</div>
</div>
</div>
</section>
</body>
</html>